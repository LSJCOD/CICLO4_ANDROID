package usa.salamanca.reto2.ui.slideshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import usa.salamanca.reto2.R;
import usa.salamanca.reto2.databinding.FragmentSlideshowBinding;

public class SlideshowFragment extends Fragment {

    private SlideshowViewModel slideshowViewModel;
    private FragmentSlideshowBinding binding;
    private ImageButton Ib1, Ib2, Ib3;
    private TextView Tv1, Tv2, Tv3;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                new ViewModelProvider(this).get(SlideshowViewModel.class);

        binding = FragmentSlideshowBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        Ib1 = (ImageButton) binding.imgBtnDirUno;
        Ib2 = (ImageButton) binding.imgBtnDirDos;
        Ib3 = (ImageButton) binding.imgBtnDirTres;


        Ib1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"Dirrección Confirmada " + Tv1 ,Toast.LENGTH_SHORT).show();
            }
        });

        Ib2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"Dirrección Confirmada"+ Tv2 ,Toast.LENGTH_SHORT).show();
            }
        });

        Ib3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"Dirrección Confirmada" + Tv3,Toast.LENGTH_SHORT).show();
            }
        });




        final TextView textView = binding.txtTileProducts;
        slideshowViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}