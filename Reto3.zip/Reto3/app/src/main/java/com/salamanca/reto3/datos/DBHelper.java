package com.salamanca.reto3.datos;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    private SQLiteDatabase sqLiteDatabase;

    public DBHelper(@Nullable Context context) {
        super(context, "reto3.db", null, 1);

        sqLiteDatabase = getWritableDatabase();
    }

    //Creacion Tabla
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE PRODUCTOS(" +
                "ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "NAME VARCHAR," +
                "IMAGE BLOB)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS PRODUCTOS");
    }

    //Funciones personalizadas

    //    Crear Registros
    public void insertProducto(String name, byte[] image) {
        String sql = "INSERT  INTO PRODUCTOS VALUES (NULL,?,?)";
        SQLiteStatement statement = sqLiteDatabase.compileStatement(sql);
        statement.clearBindings();

        statement.bindString(1, name);
        statement.bindBlob(2, image);

        statement.executeInsert();
    }

    //    Mostrar todos los Registros
    public Cursor getProducto() {
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM PRODUCTOS", null);
        return cursor;

    }

    //Mostrar Registro por ID
    public Cursor getProductoByID(String id) {
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM PRODUCTOS WHERE ID = " + id, null);
        return cursor;

    }

    //Eliminar Registros por ID
    public void deleteProducto(String id) {
        String[] args = new String[]{id};
        sqLiteDatabase.delete("PRODUCTOS", "ID=?", args);
    }

    //Actualizar por ID
    public void updateProducto(String id, String name, byte[] image) {
        String sql = "UPDATE PRODUCTO " +
                "SET NAME = ?," +
                "IMAGE = ?";
        SQLiteStatement statement = sqLiteDatabase.compileStatement(sql);
        statement.clearBindings();

        statement.bindString(1, name);
        statement.bindBlob(2, image);

        statement.executeUpdateDelete();

    }


}

