package com.salamanca.reto3.presentacion;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.salamanca.reto3.Caso_Uso.CasoUsoProducto;
import com.salamanca.reto3.R;
import com.salamanca.reto3.datos.DBHelper;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    //Inicializacion de Variables
    private Button btnInsertar, btnConsultar, btnEliminar, btnChoose, btnListaProductos;
    private EditText edtName, edtId;
    private ImageView imgSelected;
    private DBHelper dbHelper;
    private CasoUsoProducto casoUsoProducto;


    private final static String CHANNEL_ID = "NOTIFICACION";
    private final static int NOTIFICATION_ID = 0;
    private final static int READ_CODE_GALLERY = 999;


    private LinearLayout linearLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnInsertar = (Button) findViewById(R.id.btnInsertar);
        btnConsultar = (Button) findViewById(R.id.btnConsultar);
        btnEliminar = (Button) findViewById(R.id.btnEliminar);
        btnChoose = (Button) findViewById(R.id.btnChoose);
        btnListaProductos = (Button) findViewById(R.id.btnListaProductos);

        imgSelected = (ImageView) findViewById(R.id.imgSelectec);

        edtName = (EditText) findViewById(R.id.edtName);
        edtId = (EditText) findViewById(R.id.edtId);

        linearLayout = (LinearLayout) findViewById(R.id.MainLayout);

        dbHelper = new DBHelper(getApplicationContext());
        casoUsoProducto = new CasoUsoProducto();


//        LLammar lista Personajes
        btnListaProductos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListaProducto.class);
                startActivity(intent);
            }

        });

//        LLamar imagenes desde el Celular
        btnChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(
                        MainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        READ_CODE_GALLERY
                );
            }
        });


//        Mensaje Emergente
        btnInsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    dbHelper.insertProducto(
                            edtName.getText().toString().trim(),
                            imageViewToByte(imgSelected)
                    );

                    limpiarCampos();
                    Toast.makeText(getApplicationContext(), "Producto Registrado", Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

//        Notificaciones
        btnConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = edtId.getText().toString().trim();
                if (id.equals("")) {
                    Cursor cursor = dbHelper.getProducto();
                    String result = casoUsoProducto.cursorToString(cursor);
                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                } else {

                    Cursor cursor = dbHelper.getProductoByID(id);
                    showById(cursor);
                }
            }
        });
//       Dialogos
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = edtId.getText().toString().trim();
                if (id.equals("")) {
                    Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_SHORT).show();
                } else {
                    dbHelper.deleteProducto(id);
                    limpiarCampos();
                }
            }
        });
    }


    //Funcion de Limpiar Campos

    public void limpiarCampos() {
        edtName.setText("");
        imgSelected.setImageResource(R.mipmap.ic_launcher);
    }

    public void showById(Cursor cursor) {
        if (cursor.getCount() == 0) {
            Toast.makeText(getApplicationContext(), "Producto Inexistente", Toast.LENGTH_SHORT).show();
        } else {
            StringBuffer buffer = new StringBuffer();
            while (cursor.moveToNext()) {
                edtName.setText(cursor.getString(1));
                byte[] image = cursor.getBlob(2);
                Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
                imgSelected.setImageBitmap(bitmap);

            }
        }
    }


    //    Funcion de Conversion de ImageView a Byte
    public byte[] imageViewToByte(ImageView imageView) {
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }


//    Funcion Solicitud de permisos para imagenes

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == READ_CODE_GALLERY) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, READ_CODE_GALLERY);
            } else {
                Toast.makeText(getApplicationContext(), "Permisos Denegados", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

//    Extraccion de Imagenes de la gallery - Aprobados

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == READ_CODE_GALLERY && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imgSelected.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    //Funcion para Notificaciones (Creacion de Canal para Oreo o Superior)
    public void createNotificationChanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notification";
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    //Funcion para Notificaciones
    public void createNotifications(String titulo, String contenido) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID);
        builder.setSmallIcon(R.mipmap.ic_app);
//        builder.setLargeIcon(R.mipmap.ic_app);
        builder.setContentTitle(titulo);
        builder.setContentText(contenido);
        builder.setDefaults(NotificationCompat.PRIORITY_DEFAULT);
        builder.setColor(Color.BLUE);
        builder.setLights(Color.MAGENTA, 500, 500);
        builder.setVibrate(new long[]{1000, 1000, 1000, 1000, 1000, 1000});
        builder.setDefaults(Notification.DEFAULT_SOUND);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(getApplicationContext());
        notificationManagerCompat.notify(NOTIFICATION_ID, builder.build());
    }

    //Funcion de Dialogos
    public void createDialog(String titulo, String contenido) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(titulo);
        builder.setMessage(contenido)
                .setPositiveButton("SI", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Si precionado", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "No precionado", Toast.LENGTH_SHORT).show();
                    }
                }).show();

    }

    //    Funcion Mensjes
    public void createMensaje() {
        Snackbar snackbar = Snackbar.make(linearLayout, "Hola Mensaje", Snackbar.LENGTH_SHORT);
        snackbar.setAction("Llamar Toast", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Toast desde mensaje", Toast.LENGTH_SHORT).show();
            }
        });
        snackbar.show();

    }
}