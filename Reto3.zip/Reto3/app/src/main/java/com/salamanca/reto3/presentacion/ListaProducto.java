package com.salamanca.reto3.presentacion;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.GridView;

import com.salamanca.reto3.R;
import com.salamanca.reto3.datos.DBHelper;
import com.salamanca.reto3.modelo.Producto;
import com.salamanca.reto3.modelo.ProductoAdapter;

import java.util.ArrayList;


public class ListaProducto extends AppCompatActivity {
    private DBHelper dbHelper;
    private ArrayList<Producto> listaProductos;
    private GridView gridView;


    public ArrayList<Producto> llenarLista(Cursor cursor) {
        ArrayList<Producto> list = new ArrayList<>();
        if (cursor.getCount() == 0) {
            return list;
        } else {
            StringBuffer buffer = new StringBuffer();
            while (cursor.moveToNext()) {
                Producto producto = new Producto(
                        cursor.getString(1),
                        cursor.getBlob(2)
                );
                list.add(producto);
            }
            return list;
        }
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_producto);
        dbHelper = new DBHelper(getApplicationContext());
        gridView = (GridView) findViewById(R.id.gridView);

        Cursor cursor = dbHelper.getProducto();
        listaProductos = llenarLista(cursor);
        ProductoAdapter productoAdapter = new ProductoAdapter(getApplicationContext(), listaProductos);
        gridView.setAdapter(productoAdapter);

    }
}

