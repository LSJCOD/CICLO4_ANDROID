package usa.salamanca.reto1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class ProductsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_productos);

        ImageButton botonaccesorios = (ImageButton) findViewById(R.id.button0);
        botonaccesorios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Accesorios Navideños",Toast.LENGTH_SHORT).show();
            }
        });

        ImageButton botonvelas = (ImageButton) findViewById(R.id.button1);
        botonvelas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Velas Navideñas",Toast.LENGTH_SHORT).show();
            }
        });
        ImageButton botonpeluches = (ImageButton) findViewById(R.id.button2);
        botonpeluches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Peluches Navideños",Toast.LENGTH_SHORT).show();
            }
        });
        ImageButton botonpecebres = (ImageButton) findViewById(R.id.button3);
        botonpecebres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Pesebres",Toast.LENGTH_SHORT).show();
            }
        });
        ImageButton botonarboles = (ImageButton) findViewById(R.id.button4);
        botonarboles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Arboles Navideños",Toast.LENGTH_SHORT).show();
            }
        });


    }

    //*********************************************MENU*********************************************

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menupricipal,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id==R.id.MenuProducts){
            Toast.makeText(this,"Nuestros Productos",Toast.LENGTH_SHORT).show();
            Intent ProductsActivity = new Intent(getApplicationContext(), ProductsActivity.class);
            startActivity(ProductsActivity);
        }
        if (id==R.id.MenuCerrarS){
            Toast.makeText(this,"Sesión Cerrada, Vuelve Pronto",Toast.LENGTH_SHORT).show();
            Intent MainActivity = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(MainActivity);
        }
        if (id==R.id.MenuRestPassword){
            Toast.makeText(this,"Cambio de Contraseña",Toast.LENGTH_SHORT).show();
            Intent RestPasswordActivity = new Intent(getApplicationContext(), RestPasswordActivity.class);
            startActivity(RestPasswordActivity);
        }

        return super.onOptionsItemSelected(item);
    }
}